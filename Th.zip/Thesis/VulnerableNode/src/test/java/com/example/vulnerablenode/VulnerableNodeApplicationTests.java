package com.example.vulnerablenode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VulnerableNodeApplicationTests {

    @Test
    void contextLoads() {
    }

}
