package com.example.managing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagingApplicationTests {

    @Test
    void contextLoads() {
    }

}
