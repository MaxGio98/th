package com.example.managing.simple.exceptions;

public class NoSatisfyingImprovementFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	

}
