package com.example.managing.simple.data;

public class AttackVectors {


	
}
